const Inicial = () => {

	return(

	<h1>INICIAL</h1>
	)

}

export {Inicial} 
