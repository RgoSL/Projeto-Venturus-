import style from './Forms.module.css'

const Forms = () => {
	return (
		<div className={style.f_container}>
		<form>
		<legend>Preencha os dados para criar o card do colaborador</legend>

		<label htmlFor="fname">Nome</label>
		<input type="text" id="fname" name="fname" />

		<label htmlFor="fcargo">Cargo</label>
		<input type="text" id="fcargo" name="fcargo" />

		<label htmlFor="fimagem">Imagem</label>
		<input type="text" id="fimagem" name="fimagem" />

		<label htmlFor="ftime">Time</label>
		<select id="ftime" name="ftime">
		<option value="">Selecione um time</option>
		<option value="Escola">Escola</option>
		<option value="Lazer">Lazer</option>
		<option value="Profissionaç">Profissional</option>
		</select>

		<button type="submit">Criar Card</button>
		</form>
		</div>
	);
}

export { Forms };
