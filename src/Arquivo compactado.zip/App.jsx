import React, { Fragment } from "react";
import "./Global.css"

import { BrowserRouter as Router } from "react-router-dom";
import { Forms,Inicial} from './components/'
export default function App() {
  return (
  <Router>

	<Forms/>
</Router>
  );
}
